import java.util.ArrayList;
import java.util.List;

abstract class Funcionario {
    protected String nome;
    protected String CPF;
    protected double salarioBase;

    public Funcionario(String nome, String CPF, double salarioBase) {
        this.nome = nome;
        this.CPF = CPF;
        this.salarioBase = salarioBase;
    }

    public static class CPFValidator {
        public static boolean verificaCPF(String CPF) {
            CPF = CPF.replace(".", "").replace("-", "");

            // Verifica se o CPF possui 11 dígitos
            if (CPF.length() != 11) {
                return false;
            }

            // Verifica se todos os dígitos são iguais
            boolean digitosIguais = true;
            for (int i = 1; i < CPF.length(); i++) {
                if (CPF.charAt(i) != CPF.charAt(0)) {
                    digitosIguais = false;
                    break;
                }
            }
            if (digitosIguais) {
                return false;
            }

            // Cálculo do primeiro dígito verificador
            int soma = 0;
            for (int i = 0; i < 9; i++) {
                soma += Character.getNumericValue(CPF.charAt(i)) * (10 - i);
            }
            int resto = soma % 11;
            int digitoVerificador1 = (resto < 2) ? 0 : 11 - resto;

            // Verifica o primeiro dígito verificador
            if (Character.getNumericValue(CPF.charAt(9)) != digitoVerificador1) {
                return false;
            }

            // Cálculo do segundo dígito verificador
            soma = 0;
            for (int i = 0; i < 10; i++) {
                soma += Character.getNumericValue(CPF.charAt(i)) * (11 - i);
            }
            resto = soma % 11;
            int digitoVerificador2 = (resto < 2) ? 0 : 11 - resto;

            // Verifica o segundo dígito verificador
            if (Character.getNumericValue(CPF.charAt(10)) != digitoVerificador2) {
                return false;
            }

            return true;
        }
    }

    public abstract double calculaSalario();
}

class Gerente extends Funcionario {
    public Gerente(String nome, String CPF, double salarioBase) {
        super(nome, CPF, salarioBase);
    }

    @Override
    public double calculaSalario() {
        return 2 * salarioBase;
    }
}

class Assistente extends Funcionario {
    public Assistente(String nome, String CPF, double salarioBase) {
        super(nome, CPF, salarioBase);
    }

    @Override
    public double calculaSalario() {
        return salarioBase;
    }
}

class Vendedor extends Funcionario {
    private double comissao;

    public Vendedor(String nome, String CPF, double salarioBase, double comissao) {
        super(nome, CPF, salarioBase);
        this.comissao = comissao;
    }

    @Override
    public double calculaSalario() {
        return salarioBase + comissao;
    }
}

public class TesteFuncionario {
    public static void main(String[] args) {
        List<Funcionario> funcionarios = new ArrayList<>(); // criação de uma lista de funcionários inicialmente vazia

        // Criando objetos de cada tipo de funcionários
        Gerente gerente1 = new Gerente("Quixote", "111.111.111-11", 5000);
        Assistente assistente1 = new Assistente("Maggie", "222.222.222-22", 2000);
        Assistente assistente2 = new Assistente("Aylla", "333.333.333-33", 2000);
        Vendedor vendedor1 = new Vendedor("Alan", "444.444.444-44", 1500, 500);
        Vendedor vendedor2 = new Vendedor("Pit", "555.555.555-55", 1500, 500);
        Vendedor vendedor3 = new Vendedor("Nina", "666.666.666-66", 1500, 500);

        // Adicionando os funcionários à lista
        funcionarios.add(gerente1);
        funcionarios.add(assistente1);
        funcionarios.add(assistente2);
        funcionarios.add(vendedor1);
        funcionarios.add(vendedor2);
        funcionarios.add(vendedor3);

        // Calculando a folha salarial
        double folhaSalarial = 0;
        for (Funcionario funcionario : funcionarios) {
            folhaSalarial += funcionario.calculaSalario();
        }

        // Imprimindo o valor total da folha salarial
        System.out.println("Folha Salarial: R$" + folhaSalarial);
    }
}
